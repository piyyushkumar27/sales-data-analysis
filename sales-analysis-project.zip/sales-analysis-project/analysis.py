"""Sales analysis with pandas.
Run:  py analysis.py   (after generate_data.py)
"""
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 1. Load
df = pd.read_csv("sales_data.csv", parse_dates=["order_date"])
print("Rows loaded:", len(df))

# 2. Clean
df = df.drop_duplicates()
df["city"] = df["city"].fillna("Unknown")
print("Rows after cleaning:", len(df))

# 3. Questions and answers
total_revenue = df["revenue"].sum()
print(f"\nTotal revenue: Rs {total_revenue:,.0f}")

by_category = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
print("\nRevenue by category:\n", by_category.round(0))

top_products = df.groupby("product")["revenue"].sum().sort_values(ascending=False).head(5)
print("\nTop 5 products by revenue:\n", top_products.round(0))

by_city = df.groupby("city")["revenue"].sum().sort_values(ascending=False)
print("\nRevenue by city:\n", by_city.round(0))

df["month"] = df["order_date"].dt.to_period("M").astype(str)
monthly = df.groupby("month")["revenue"].sum()
print("\nBest month:", monthly.idxmax(), f"(Rs {monthly.max():,.0f})")

by_payment = df["payment_method"].value_counts()
print("\nOrders by payment method:\n", by_payment)

# 4. Charts
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
monthly.plot(ax=axes[0], marker="o", title="Monthly revenue")
axes[0].set_ylabel("Revenue (Rs)")
axes[0].tick_params(axis="x", rotation=45)
by_category.plot(kind="bar", ax=axes[1], title="Revenue by category")
axes[1].set_ylabel("Revenue (Rs)")
plt.tight_layout()
plt.savefig("charts.png", dpi=120)
print("\nSaved charts.png")
