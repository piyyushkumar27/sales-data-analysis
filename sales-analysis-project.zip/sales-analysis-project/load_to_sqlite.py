"""Loads the cleaned CSV into a SQLite database and runs queries.sql.
Run:  py load_to_sqlite.py
You can also open sales.db in the free app 'DB Browser for SQLite'.
"""
import sqlite3

import pandas as pd

df = pd.read_csv("sales_data.csv").drop_duplicates()
df["city"] = df["city"].fillna("Unknown")

conn = sqlite3.connect("sales.db")
df.to_sql("sales", conn, if_exists="replace", index=False)
print(f"Loaded {len(df)} rows into sales.db (table: sales)\n")

queries = [q.strip() for q in open("queries.sql").read().split(";") if "SELECT" in q]
for i, q in enumerate(queries, 1):
    # Skip the comment lines when printing the result
    print(f"--- Query {i} ---")
    print(pd.read_sql_query(q, conn).to_string(index=False), "\n")

conn.close()
