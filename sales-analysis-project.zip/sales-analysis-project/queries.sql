-- 10 practice queries. Table name: sales  (created by load_to_sqlite.py)
-- Try to write each one yourself first, then compare with these.

-- 1. How many orders are there?
SELECT COUNT(*) AS total_orders FROM sales;

-- 2. Total revenue
SELECT ROUND(SUM(revenue), 0) AS total_revenue FROM sales;

-- 3. Revenue by category (highest first)
SELECT category, ROUND(SUM(revenue), 0) AS revenue
FROM sales
GROUP BY category
ORDER BY revenue DESC;

-- 4. Top 5 products by revenue
SELECT product, ROUND(SUM(revenue), 0) AS revenue
FROM sales
GROUP BY product
ORDER BY revenue DESC
LIMIT 5;

-- 5. Revenue by city
SELECT city, ROUND(SUM(revenue), 0) AS revenue
FROM sales
GROUP BY city
ORDER BY revenue DESC;

-- 6. Revenue by month
SELECT SUBSTR(order_date, 1, 7) AS month, ROUND(SUM(revenue), 0) AS revenue
FROM sales
GROUP BY month
ORDER BY month;

-- 7. Which payment method is used most?
SELECT payment_method, COUNT(*) AS orders
FROM sales
GROUP BY payment_method
ORDER BY orders DESC;

-- 8. Average order value per category
SELECT category, ROUND(AVG(revenue), 0) AS avg_order_value
FROM sales
GROUP BY category;

-- 9. Orders with a discount of 10% or more
SELECT COUNT(*) AS discounted_orders
FROM sales
WHERE discount_percent >= 10;

-- 10. Cities with more than Rs 50 lakh revenue
SELECT city, ROUND(SUM(revenue), 0) AS revenue
FROM sales
GROUP BY city
HAVING SUM(revenue) > 5000000
ORDER BY revenue DESC;
