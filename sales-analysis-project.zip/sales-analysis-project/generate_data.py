"""Creates sales_data.csv, a practice dataset for this project.

NOTE: this is made-up (synthetic) data so you can start immediately.
Later, swap it for a real dataset from Kaggle and redo the analysis.
Run:  py generate_data.py
"""
import random
from datetime import date, timedelta

import pandas as pd

random.seed(42)

products = {
    "Laptop": ("Electronics", 45000),
    "Smartphone": ("Electronics", 18000),
    "Headphones": ("Electronics", 2500),
    "Office Chair": ("Furniture", 7000),
    "Study Desk": ("Furniture", 9500),
    "Notebook Pack": ("Stationery", 300),
    "Pen Set": ("Stationery", 150),
    "Backpack": ("Accessories", 1800),
}
cities = ["Jaipur", "Delhi", "Mumbai", "Bangalore", "Kolkata", "Sikar"]
payments = ["UPI", "Card", "Cash", "Net Banking"]

rows = []
start = date(2025, 1, 1)
for order_id in range(1, 2001):
    product = random.choice(list(products))
    category, price = products[product]
    qty = random.randint(1, 5) if price < 5000 else random.randint(1, 2)
    order_date = start + timedelta(days=random.randint(0, 364))
    discount = random.choice([0, 0, 0, 5, 10])
    revenue = round(price * qty * (1 - discount / 100), 2)
    rows.append(
        {
            "order_id": order_id,
            "order_date": order_date.isoformat(),
            "city": random.choice(cities),
            "category": category,
            "product": product,
            "unit_price": price,
            "quantity": qty,
            "discount_percent": discount,
            "payment_method": random.choice(payments),
            "revenue": revenue,
        }
    )

df = pd.DataFrame(rows)

# Add a few messy rows on purpose, so you can practise cleaning in Excel.
df.loc[[10, 250, 900], "city"] = None
df = pd.concat([df, df.iloc[[5, 77]]], ignore_index=True)  # 2 duplicate rows

df.to_csv("sales_data.csv", index=False)
print(f"Saved sales_data.csv with {len(df)} rows")
