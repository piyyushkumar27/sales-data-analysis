# Sales Data Analysis: Excel, SQL, Python and Power BI

**Question:** Which products, categories, cities and months drive the most revenue, and where should a business focus?

**Dataset:** 2,000 orders across 8 products, 4 categories and 6 cities (Jan to Dec 2025).
`sales_data.csv` is synthetic practice data made by `generate_data.py`. Replace it with a real
Kaggle dataset when you can, and say so honestly in your write-up.

## Files
| File | What it does |
|---|---|
| `generate_data.py` | Creates `sales_data.csv` (with a few messy rows on purpose) |
| `analysis.py` | Cleans the data with pandas, answers the questions, saves `charts.png` |
| `load_to_sqlite.py` | Loads the data into `sales.db` and runs `queries.sql` |
| `queries.sql` | 10 SQL queries |

## How to run (Windows)
```
py -m pip install pandas matplotlib
py generate_data.py
py analysis.py
py load_to_sqlite.py
```

## Your tasks (do these yourself; this is what you learn from)

### 1. Python (pandas)
Read `analysis.py` line by line. Then change it to answer one new question of your own,
for example: "Which city buys the most Laptops?"

### 2. SQL
Try to write each query in `queries.sql` yourself before reading mine. Open `sales.db` in
DB Browser for SQLite (free) and run them there. Then write 3 new queries of your own.

### 3. Excel
1. Open `sales_data.csv` in Excel and save it as `sales_data.xlsx`.
2. Clean it: Data > Remove Duplicates (2 duplicate rows), and fill the blank city cells with "Unknown".
3. Insert > PivotTable: Rows = category, Values = Sum of revenue. Add a second pivot by month.
4. Add two charts: revenue by category (bar) and revenue by month (line).
5. Check that your Excel total matches the Python and SQL totals.

### 4. Power BI
1. Get Data > Text/CSV > `sales_data.csv` > Transform Data.
2. Remove duplicates, replace null city with "Unknown", set `order_date` to Date type.
3. Build one page with: a total revenue card, revenue by category (bar), revenue by month (line),
   revenue by city (map or bar), and slicers for category and city.
4. Take a screenshot and put it in this folder.

## Findings (fill in your own after you run everything)
- Electronics brings in about 74% of revenue, and Laptops alone are the biggest product.
- Revenue by city is fairly even, with Jaipur, Bangalore and Kolkata leading.
- Write 3 more insights in your own words, and one recommendation for the business.

## A note on small differences
Python shows total revenue as Rs 29,807,612 while SQL shows 29,807,613. The true value ends in .5,
and the two tools round halves differently. Explaining this in an interview shows you checked
your numbers.

## Your CV line (use it only after you've done all four tasks yourself)
> Analysed 2,000 sales orders using Excel (pivot tables), SQL (SQLite), Python (pandas) and Power BI,
> and built an interactive dashboard to identify top products, cities and months by revenue.
